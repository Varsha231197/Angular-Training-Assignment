import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor() { }
  
  products = [
  {category: 'Sporting Goods', price: '$49.99', stocked: true, name: 'Football'},
  {category: 'Sporting Goods', price: '$9.99', stocked: true, name: 'Baseball'},
  {category: 'Sporting Goods', price: '$29.99', stocked: false, name: 'Basketball'},  
  {category: 'Electronics', price: '$99.99', stocked: true, name: 'iPod Touch'},
  {category: 'Electronics', price: '$399.99', stocked: false, name: 'iPhone 5'},
  {category: 'Electronics', price: '$199.99', stocked: true, name: 'Nexus 7'},
];

  getAllProducts(){
    return this.products;
  }

  

//used in product table component
searchProductsCategorywise(searchStr:string){
  console.log(searchStr)
  type product={category: string,price: string, stocked: boolean, name: string};
  let lastCategory:any=null;
  let prodMap:Map<string,product[]>=new Map<string,product[]>(); 

  
  
  let myProd:product[]=[]; 

  let categories:string[]=[];

  this.products.forEach((p) => {      
    if(p.category!== lastCategory){         
      lastCategory=p.category; 
      categories.push(lastCategory);
      console.log("lastcat : "+lastCategory)
    }
  }); 

  categories.forEach((c)=>{
    myProd=[];
    this.products.forEach((p)=>{
      if(p.category.includes(c)){
        if(!searchStr)
             myProd.push({category: p.category,price: p.price, stocked: p.stocked, name: p.name});     
        else if(JSON.stringify(p).toLocaleLowerCase().includes(searchStr))             
             myProd.push({category: p.category,price: p.price, stocked: p.stocked, name: p.name});             
      }
    });
    if(myProd.length>0) //If products are found in category as per search string
       prodMap.set(c,myProd);
       
  });
   console.log(prodMap); 
  //  console.log(prodKey); 
  //  console.log(prodValue)  
   return prodMap;
}


}