import { Component, Input, OnInit } from '@angular/core';
import { ProductService } from 'src/app/utility/product.service';

@Component({
  selector: 'app-product-table',
  templateUrl: './product-table.component.html',
  styleUrls: ['./product-table.component.scss']
})
export class ProductTableComponent implements OnInit {

  _search: string = '';
get search(): string {
    return this._search;
}
@Input() set search(newFlag: string) {
    this._search = newFlag;
    this.doSomething( );
}



  myProducts:any;

  constructor(private _productService:ProductService) { }

  ngOnInit(): void {
    
  }

  doSomething(){
    this.myProducts=this._productService.searchProductsCategorywise(this._search);
  }
  
  isInStockChecked:boolean=false;
  onCheckboxChange(e:any) {   
      this.isInStockChecked=!this.isInStockChecked;
  }

  
}
